package com.vehicle.Restwebservice.vehicleRestwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleRestwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleRestwebserviceApplication.class, args);
	}
}
