package com.vehicle.Restwebservice.vehicleRestwebservice;


@SuppressWarnings("serial")
public class VehicleNotFoundException extends RuntimeException {


	public VehicleNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}